# MiPlayer

Reproductor de música personal para iPhone con interfaz inspirada en Spotify.
Reproduce **solo archivos locales** (sin internet), con ecualizador de 10 bandas,
efectos de mezcla y apariencia 100 % personalizable. SwiftUI, iOS 17+.

## Instalarla en tu iPhone (necesitas una Mac con Xcode 15 o superior)

### Opción A: manual (la más segura)

1. Xcode → **File ▸ New ▸ Project ▸ iOS ▸ App**.
   - Product Name: `MiPlayer` · Interface: **SwiftUI** · Language: **Swift**.
   - Minimum Deployments: **iOS 17.0**.
2. Borra `ContentView.swift` y el `MiPlayerApp.swift` que genera Xcode.
3. Arrastra **todos** los `.swift` de la carpeta `MiPlayer/MiPlayer/` al proyecto
   (marca “Copy items if needed” y tu target).
4. Selecciona el proyecto → target → pestaña **Signing & Capabilities**:
   - Elige tu Apple ID en *Team*.
   - **+ Capability ▸ Background Modes ▸ marca “Audio, AirPlay, and Picture in Picture”**
     (para que suene con la pantalla bloqueada).
5. Pestaña **Info** del target → agrega dos filas:
   - `Application supports iTunes file sharing` = **YES**
   - `Supports opening documents in place` = **YES**
   (así la carpeta de la app aparece en la app Archivos).
   Si Xcode 16/26 muestra errores de concurrencia: Build Settings ▸ **Swift Language Version = Swift 5**.
6. Conecta el iPhone, actívalo como destino y pulsa **Run ▶**.
   La primera vez: Ajustes del iPhone ▸ General ▸ VPN y gestión de dispositivos ▸ confía en tu Apple ID.
   Con un Apple ID gratis la app caduca a los 7 días y se vuelve a instalar con Run; con la cuenta de pago dura un año.

### Opción B: con XcodeGen (opcional)

Si tienes Homebrew: `brew install xcodegen`, edita `project.yml` (cambia `com.tuusuario`),
ejecuta `xcodegen generate` y abre `MiPlayer.xcodeproj`. Luego solo falta elegir tu *Team*.

### Opción C: sin Mac y sin pagar (IPA + sideloading)

iOS solo instala apps firmadas, así que el “APK de iPhone” (.ipa) se firma en tu propio teléfono con un Apple ID **gratis**.

1. Crea una cuenta gratis en github.com y un repositorio **público** nuevo.
2. Sube el contenido de esta carpeta (que `project.yml` quede en la raíz del repo, junto con `.github/` y `MiPlayer/`).
3. Pestaña **Actions ▸ Construir IPA ▸ Run workflow**. Tarda unos 5–10 minutos (usa un Mac en la nube, gratis en repos públicos).
4. Al terminar, descarga el artefacto **MiPlayer-ipa** y descomprímelo para obtener `MiPlayer.ipa`.
5. Instálalo con **Sideloadly** (Windows/Mac, sideloadly.io) o **AltStore** (altstore.io): conecta el iPhone, arrastra el `.ipa` e inicia sesión con tu Apple ID.
6. En el iPhone: Ajustes ▸ General ▸ VPN y gestión de dispositivos ▸ confía en tu Apple ID. Activa **Modo Desarrollador** (Ajustes ▸ Privacidad y seguridad) si te lo pide.

Con Apple ID gratis la app **caduca cada 7 días**. AltStore la renueva sola si tu computadora está encendida en la misma red Wi-Fi; con Sideloadly basta con volver a instalarla.
Al reinstalar encima, tu biblioteca se conserva.

## Cómo meter tus canciones

- **Importar** (Biblioteca ▸ **+** ▸ *Importar canciones o carpeta*, o en Ajustes):
  abre el selector de Archivos, donde aparecen iCloud Drive, Dropbox, Google Drive, etc.
  La app **copia** los archivos al teléfono (por eso funciona sin conexión) y lee título, artista, álbum y portada.
  Si un archivo de iCloud no está descargado, el sistema lo baja durante la importación.
  Con carpetas, descarga antes la carpeta en Archivos (“Descargar ahora”) para que todo se importe.
- **Desde la app Archivos**: *En mi iPhone ▸ MiPlayer ▸ Music*. Pega ahí tus archivos;
  al volver a MiPlayer los detecta solos (o usa *Buscar archivos nuevos*).
  Si borras un archivo desde Archivos, desaparece de la biblioteca.

Formatos: MP3, M4A/AAC, WAV, AIFF, CAF, FLAC, ALAC. (OGG/OPUS no los soporta iOS de forma nativa.)

## Qué incluye

**Interfaz tipo Spotify**: Inicio (saludo, accesos rápidos, carruseles), Buscar (explorar + resultados),
Tu biblioteca (filtros, lista/cuadrícula, orden), listas propias (crear, renombrar, reordenar),
favoritas, álbumes y artistas automáticos, mini reproductor, pantalla de reproducción completa, cola,
control desde la pantalla de bloqueo y los auriculares.

**Audio**
- Ecualizador de 10 bandas (32 Hz–16 kHz) con 13 preajustes y sliders verticales.
- Preamplificador y protección anti-distorsión automática.
- Velocidad (0.5×–2×), tono (±12 semitonos), balance izquierda/derecha.
- Reverberación con 7 ambientes.
- **Perfiles de audio guardables** (p. ej. “Audífonos”, “Auto”) que aplicas con un toque.

**Personalización** (Ajustes): 8 temas listos, colores de acento/fondo/tarjetas/texto,
radio de esquinas, tipografía, filas compactas, qué secciones muestra el inicio y tu nombre en el saludo.
Todo se guarda y se aplica al instante.

## Limitaciones honestas

- **Sincronizar con la nube** funciona *a través del selector de Archivos* (copia manual/semi-manual).
  Una sincronización automática en segundo plano requeriría el contenedor de iCloud de la app,
  que exige una cuenta de desarrollador de pago; se puede agregar después.
- No hay *crossfade* (fundido entre canciones) ni normalización de volumen todavía.
- La app no la pude compilar aquí (no hay Xcode en mi entorno). Si Xcode marca algún error al
  compilar, pégamelo y lo corrijo.
